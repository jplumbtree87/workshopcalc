﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WorkshopCalc
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        const int HANDLING_STRESS_DAYS = 3;
        const int TIME_MANAGEMENT_DAYS = 3;
        const int SUPERVISION_DAYS = 3;
        const int NEGOTIATION_DAYS = 5;
        const int INTERVIEW_DAYS = 1;
        const double HANDLING_STRESS_FEE = 1000.00;
        const double TIME_MANAGEMENT_FEE = 800.00;
        const double SUPERVISION_FEE = 1500.00;
        const double NEGOTIATION_FEE = 1300.00;
        const double INTERVIEW_FEE = 500.00;
        const double AUSTIN_LODGE = 150.00;
        const double CHICAGO_LODGE = 225.00;
        const double DALLAS_LODGE = 175.00;
        const double ORLANDO_LODGE = 300.00;
        const double PHOENIX_LODGE = 175.00;
        const double RALEIGH_LODGE = 150.00;

        int days;
        double fee;
        double lodging;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnCalc_Click(object sender, RoutedEventArgs e)
        {
            if (lbWorkshop.SelectedIndex.Equals(-1) || lbWorkshop.SelectedIndex.Equals(-1))
            {
                MessageBox.Show("Please select a city and a workshop");
            }
            else
            {
                tblPrice.Text = "Cost of selected workshop: $" + ((decimal)((lodging * days) + fee)).ToString("F2");
            }
        }

        private void lbWorkshop_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (lbWorkshop.SelectedIndex.Equals(0))
            {
                days = HANDLING_STRESS_DAYS;
                fee = HANDLING_STRESS_FEE;
            }
            if (lbWorkshop.SelectedIndex.Equals(1))
            {
                days = TIME_MANAGEMENT_DAYS;
                fee = TIME_MANAGEMENT_FEE;
            }
            if (lbWorkshop.SelectedIndex.Equals(2))
            {
                days = SUPERVISION_DAYS;
                fee = SUPERVISION_FEE;
            }
            if (lbWorkshop.SelectedIndex.Equals(3))
            {
                days = NEGOTIATION_DAYS;
                fee = NEGOTIATION_FEE;
            }
            if (lbWorkshop.SelectedIndex.Equals(4))
            {
                days = INTERVIEW_DAYS;
                fee = INTERVIEW_FEE;
            }

        }

        private void lbLocation_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (lbLocation.SelectedIndex.Equals(0))
            {
                lodging = AUSTIN_LODGE;
            }
            if (lbLocation.SelectedIndex.Equals(1))
            {
                lodging = CHICAGO_LODGE;
            }
            if (lbLocation.SelectedIndex.Equals(2))
            {
                lodging = DALLAS_LODGE;
            }
            if (lbLocation.SelectedIndex.Equals(3))
            {
                lodging = ORLANDO_LODGE;
            }
            if (lbLocation.SelectedIndex.Equals(4))
            {
                lodging = PHOENIX_LODGE;
            }
            if (lbLocation.SelectedIndex.Equals(5))
            {
                lodging = RALEIGH_LODGE;
            }
        }
    }
}
